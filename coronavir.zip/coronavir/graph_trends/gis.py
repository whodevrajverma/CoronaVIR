import seaborn as sns
import matplotlib.pyplot as plt
sns.set(style="whitegrid",font_scale=2.0,color_codes=True)
import pandas as pd
import requests
import urllib.request
import time
from bs4 import BeautifulSoup
import os
os.environ[ 'MPLCONFIGDIR' ] = '/tmp/'
url = 'https://www.worldometers.info/coronavirus/'
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")
rows = soup.find_all('tr')
for row in rows:
    row_td = row.find_all('td')
str_cells = str(row_td)
cleantext = BeautifulSoup(str_cells, "lxml").get_text()
import re
list_rows = []
for row in rows:
    cells = row.find_all('td')
    str_cells = str(cells)
    clean = re.compile('<.*?>')
    clean2 = (re.sub(clean, ':',str_cells))
    list_rows.append(clean2)
df_1 = pd.DataFrame(list_rows[8:])
df1_1 = df_1[0].str.split(':,', expand=True)
df2_1 = df1_1.loc[1:]
df2_1.drop(columns=[0,3,5,7,10,11,12,13,14,15,16,17,18,19,20,21],inplace=True)
d = {
    ':': '',
    ' ': '',
    ',':'',
    ']':'',
    '\(([\d,]+)\)': r'-\1'
}

# df3_1 = df2_1.iloc[:,1:].replace(d, regex=True).astype(float)
df3_1 = df2_1.iloc[:,1:].replace(d, regex=True)
df3_1 = df3_1.replace({'':'0'}, regex=False)
df3_1[1] = df2_1[1].str.replace('[','')
df3_1[1] = df3_1[1].str.replace(':','')
df3_1[1] = df3_1[1].str.replace(' ','')
df3_1.columns = ['confirm','dead','heal','active','Serious','name']
df3_1 = df3_1[['name','confirm','dead','heal','active','Serious']]
#df3_1['confirm'] = df3_1['confirm'].str.replace('','0')
#df3_1['dead'] = df3_1['dead'].str.replace('','0')
df3_1.reset_index(drop=True,inplace=True)
df3_1 = df3_1.loc[df3_1.name != 'World'].reset_index(drop=True)
cc = df3_1.loc[df3_1.name=='Total'].index[0]
df = df3_1.iloc[:cc,:]
#######################################################################
df['dead'] = df['dead'].astype(int)
df['confirm'] = df['confirm'].astype(int)
# df['heal'] = df['heal'].astype(int)
#df['active'] = df['active'].astype(int)
#df['Serious'] = df['Serious'].astype(int)
df1 = df.loc[df['dead']>0]
#df1 = df
df2 = df.loc[df['confirm']>500]
#df2 = df
#######################################################################
f, ax = plt.subplots(figsize=(22,45))
# Load the example car crash dataset
crashes = df2.sort_values("confirm", ascending=False)
# Plot the total crashes
sns.set_color_codes("bright")
sns.barplot(x="confirm", y="name", data=crashes, color="r")

ax.legend(ncol=2, loc="lower right")
ax.set_title('Confirmed cases all over the world',fontsize=26,weight='bold')
ax.set(ylabel="",
       xlabel="Number of Confirmed cases")
sns.despine(left=True, bottom=True)
for p in ax.patches:
        width = p.get_width()
        ax.text(width -1.2 ,
            p.get_y()+p.get_height()/2. + 0.2,
            '{:1.0f}'.format(width),
            ha="left",fontweight='bold',va='center',size=20)
plt.savefig('countries.png',dpi=300,pad_inches = 0.5,bbox_inches = 'tight')
#######################################################################
f, ax = plt.subplots(figsize=(22,70))

# Load the example car crash dataset
crashes = df2.sort_values("confirm", ascending=False)

# Plot the total crashes
sns.set_color_codes("bright")
sns.barplot(x="confirm", y="name", data=crashes, color="r")
sns.set(style="whitegrid",font_scale=2)
# #Plot the crashes where alcohol was involved
# sns.set_color_codes("muted")
# sns.barplot(x="dead", y="name", data=crashes,
#             label="dead", color="b")

# Add a legend and informative axis label
ax.legend(ncol=2, loc="lower right", frameon=True)
ax.set_title('Confirmed cases all over the world',fontsize=26,weight='bold')
ax.set(ylabel="",
       xlabel="Number of Confirmed cases")
sns.despine(left=True, bottom=True)
for p in ax.patches:
        width = p.get_width()
        ax.text(width -1.2  ,
            p.get_y()+p.get_height()/2. + 0.2,
            '{:1.0f}'.format(width),
            ha="left",fontweight='bold',va='center',size=20)
plt.savefig('countries.pdf',dpi=300,pad_inches = 0.5,bbox_inches = 'tight')
#######################################################################
f, ax = plt.subplots(figsize=(22,70))

# Load the example car crash dataset
crashes = df1.sort_values("dead", ascending=False)

# Plot the total crashes
sns.set_color_codes("bright")
sns.barplot(x="dead", y="name", data=crashes, color="r")

# #Plot the crashes where alcohol was involved
# sns.set_color_codes("muted")
# sns.barplot(x="dead", y="name", data=crashes,
#             label="dead", color="b")

# Add a legend and informative axis label
ax.legend(ncol=2, loc="lower right", frameon=True)
ax.set_title('Deaths reported all over the world',fontsize=26,weight='bold')
ax.set(ylabel="",
       xlabel="Number of Deaths")
sns.despine(left=True, bottom=True)
for p in ax.patches:
        width = p.get_width()
        ax.text(width -1.2  ,
            p.get_y()+p.get_height()/2. + 0.2,
            '{:1.0f}'.format(width),
            ha="left",fontweight='bold',va='center',size=17)
plt.savefig('deaths.png',dpi=300,pad_inches = 0.5,bbox_inches = 'tight')
plt.savefig('deaths.pdf',dpi=300,pad_inches = 0.5,bbox_inches = 'tight')
# plt.savefig('destination_path.eps', format='eps')
############################################################################
import plotly.graph_objects as go
import plotly
import matplotlib.pyplot as plt
import pandas as pd

for col in df.columns:
    df[col] = df[col].astype(str)

df['text'] = df['name']+'<br>' +'Confirmed cases: ' + df['confirm'] + '<br>' + 'Deaths: ' + df['dead'] + '<br>' + \
    'Healed: ' + df['heal'] + '<br>' + 'Active cases: ' + df['active'] + '<br>' + \
    'Serious cases: ' + df['Serious']

fig = go.Figure(data=go.Choropleth(
    locations=df['name'],
    z=df['confirm'].astype(float),
    locationmode='country names',
    colorscale='reds',
    autocolorscale=False,
    text=df['text'], # hover text
    marker_line_color='black', # line markers between states
    colorbar_title="Confirmed Cases"
))

fig.update_layout(
    title_text='Spread of Coronavirus',
    title_x = 0.5,
    margin=dict(l=0, r=0, t=30, b=0),
    geo = dict(
        scope='world',
        showlakes=True, # lakes
        showframe = False,
        showcoastlines = True,
        lakecolor='rgb(255, 255, 255)'),
)

#fig.show()
plotly.offline.plot(fig, filename = '../world_map.html',auto_open=False)
