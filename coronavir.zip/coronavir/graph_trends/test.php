<html lang="en">
<body>
<img src="map.png">
<embed src="china.pdf" type="application/pdf"   height="100%" width="100%" class="responsive"></embed>
</body>
</html>
