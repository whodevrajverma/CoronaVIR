<?php include "../header.php"?>
</html>
<html lang="en">
<head>
<style>
html, body {
  min-width: 100%;
  height: 100%;
  float: left;
  display: block;
}
</style>
</head>
<body>
<embed src="merged_pdf.pdf" type="application/pdf"   height="100%" width="100%" class="responsive" style="outline:thick;padding:5px;">
</body>
<?php include "../footer.php"?>

