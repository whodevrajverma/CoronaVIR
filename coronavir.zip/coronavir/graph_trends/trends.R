library(nCov2019)
library(forcats)
library(ggplot2)
library(ggrepel)
library(tidyverse)
x<-get_nCov2019(lang='en')
final = x['global', ]
d = final[complete.cases(final), ]
drops <- c("showRate","showHeal")
e = d[ , !(names(d) %in% drops)]
names(e) <- c('Country','Confirmed_cases','Suspected_cases','No. of deaths','Death_rate','Healed_cases','Heal_rate')
write.csv(e,'corona.csv',row.names=FALSE)
######To plot the confirmed cases###############
#d[d$name=='India','confirm'] <- 73
#d[d$name=='Italy','confirm'] <- 12462
#d[d$name=='Iran','confirm'] <- 9000
#d[d$name=='Republic of Korea','confirm'] <- 7689
#d[d$name=='Japan','confirm'] <- 639
#d$confirm=as.numeric(d$confirm)
#d$name = fct_reorder(d$name, d$confirm)
#temp_plot_1=ggplot(d, aes(name, confirm)) +
#  geom_col(fill='red') + coord_flip() +
#  geom_text_repel(aes(y = confirm+2, label=confirm), hjust=1,size = 7,color='black',face='bold') +
#  theme_minimal(base_size=20) +
#  scale_y_continuous(expand=c(0,100)) +labs(title=expression(paste(underline("Confirmed cases all over the world"))))+theme(plot.title = element_text(hjust = 0.5,face = "bold"))+
#  ylab('Number of confirmed cases') + xlab('') +labs(caption = paste("accessed date:", time(x), "CST"))
#ggsave(temp_plot_1, file="countries.pdf",width = 20, height = 20, dpi =300, device='pdf')
#png("countries.png", type="cairo", width=20, height=20,unit="in", res=300)
#temp_plot_1
#dev.off()
######################################################################################################
#d$dead=as.numeric(d$dead)
#d$name = fct_reorder(d$name, d$dead)
#temp_plot_2 = ggplot(d, aes(name, dead)) +
#  geom_col(fill='red') + coord_flip() +
#  geom_text_repel(aes(y = dead+2, label=dead), hjust=1,size = 7,color='black') +
#  theme_minimal(base_size=20) +
#  scale_y_continuous(expand=c(0,100)) +labs(title=expression(paste(underline("Deaths reported all over the world"))))+theme(plot.title = element_text(hjust = 0.5,face = "bold"))+
#  ylab('Number of deaths') +xlab('')+labs(caption = paste("accessed date:", time(x), "CST"))
#ggsave(temp_plot_2, file="deaths.pdf",width = 20, height = 20, dpi =300, device='pdf')
#png("deaths.png", type="cairo", width=20, height=20,unit="in", res=300)
#temp_plot_2
#dev.off()
##########################################################################################################################################
require(chinamap)
require(nCov2019)
x = get_nCov2019(lang='en')
cn = get_map_china()
## translate province
cn$province <- trans_province(cn$province)
temp_plot_4 = plot(x, region='china', chinamap=cn, font.size=3)
ggsave(file='china.pdf',temp_plot_4,width = 10, height = 10, dpi =300, device='pdf')
png("china.png", type="cairo", width=10, height=10,unit="in", res=300)
temp_plot_4
dev.off()

##########################################################################################################################################

#x <- load_nCov2019(lang='en')
#for (val in unique(x$province$province))
#{
#  d <- x[val,] # replace Anhui with any province
#  d = d[complete.cases(d), ]
#  d = d %>%filter(str_detect(city, "Determined", negate = TRUE))
#  temp_plot=ggplot(d, aes(time, as.numeric(cum_confirm), group=city, color=city)) +
#    geom_point() + geom_line() +
#    geom_text_repel(aes(label=city), data=d[d$time == time(x), ], hjust=1) +
#    theme_minimal(base_size = 14)  + theme(legend.position='none')+
#    xlab(NULL) + ylab(NULL)+labs(title=paste('Trend in the cities of',val,sep=' '))+theme(plot.title = element_text(hjust = 0.5,face = "bold"))+labs(caption = paste("Updated on:", time(x)))
#  ggsave(temp_plot, file=paste0(val,".pdf"), width =20, height = 10, dpi =300, device='pdf')
#}
############################################################################################################################################
require(nCov2019)
x = get_nCov2019(lang='en')
#temp_plot_3 = plot(x)
#ggsave(temp_plot_3, file="map.pdf",width = 20, height = 10, dpi =300, device='pdf')
#png("map.png", type="cairo", width=20, height=10,unit="in", res=300)
#temp_plot_3
#dev.off()
###########################################################################################################
