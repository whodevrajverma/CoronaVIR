import os
import time
#cmd = "/home/users/dilraj/R/bin/Rscript trends.R"
cmd3 = "/home/users/sumeet/anaconda3/bin/python3 -W ignore gis.py"
#cmd1 = "pdfunite map.pdf china.pdf countries.pdf deaths.pdf Anhui.pdf Beijing.pdf Chongqing.pdf Fujian.pdf Gansu.pdf Guangdong.pdf Guangxi.pdf Guizhou.pdf Hainan.pdf Hebei.pdf Heilongjiang.pdf Henan.pdf Hong\ Kong.pdf Hubei.pdf Hunan.pdf Inner\ Mongolia.pdf Jiangsu.pdf Jiangxi.pdf Jilin.pdf Liaoning.pdf Macau.pdf Ningxia.pdf Qinghai.pdf Shaanxi.pdf Shandong.pdf Shanghai.pdf Shanxi.pdf Sichuan.pdf Taiwan.pdf Tianjin.pdf Tibet.pdf Xinjiang.pdf Yunnan.pdf Zhejiang.pdf merged_pdf.pdf"
cmd1 = "pdfunite map.pdf countries.pdf deaths.pdf merged_pdf.pdf"
cmd2 = "rm merged_pdf.pdf"
i=0
while i < 3:
#    os.system(cmd)
    os.system(cmd3)
    os.system(cmd2)
    os.system(cmd1)
    time.sleep(60)
