<?php include("header.php");?>
<head>
<style>
table, th, td {
  border: 2px solid black;
  border-collapse: collapse;
}
</style>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: auto;
  vertical-align:middle;
  white-space:nowrap
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #4CAF50;
  color: white;
}
</style>
<style type="text/css">

.pg-normal {
color: #000000;
font-size: 15px;
cursor: pointer;
background: #ff9966;
padding: 2px 4px 2px 4px;
}

.pg-selected {
color: #fff;
font-size: 15px;
background: #000000;
padding: 2px 4px 2px 4px;
}


table.yui .tablesorterPager {
padding: 10px 0 10px 0;
}

table.yui .tablesorterPager span {
padding: 0 5px 0 5px;
}

table.yui .tablesorterPager input.prev {
width: auto;
margin-right: 10px;
}

table.yui .tablesorterPager input.next {
width: auto;
margin-left: 10px;
}

table.yui .pagedisplay {
font-size:10pt;
width: 30px;
border: 0px;
background-color: #E1ECF9;
vertical-align:middle;
}
</style>
<style>
img {
    transition:transform 0.25s ease;
}

img:hover {
    -webkit-transform:scale(5);
    transform:scale(5);
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript">

function Pager(tableName, itemsPerPage) {

this.tableName = tableName;

this.itemsPerPage = itemsPerPage;

this.currentPage = 1;

this.pages = 0;

this.inited = false;

this.showRecords = function(from, to) {

var rows = document.getElementById(tableName).rows;

// i starts from 1 to skip table header row

for (var i = 1; i < rows.length; i++) {

if (i < from || i > to)

rows[i].style.display = 'none';

else

rows[i].style.display = '';

}

}

this.showPage = function(pageNumber) {

if (! this.inited) {

alert("not inited");

return;

}

var oldPageAnchor = document.getElementById('pg'+this.currentPage);

oldPageAnchor.className = 'pg-normal';

this.currentPage = pageNumber;

var newPageAnchor = document.getElementById('pg'+this.currentPage);

newPageAnchor.className = 'pg-selected';

var from = (pageNumber - 1) * itemsPerPage + 1;

var to = from + itemsPerPage - 1;

this.showRecords(from, to);

}

this.prev = function() {

if (this.currentPage > 1)

this.showPage(this.currentPage - 1);

}

this.next = function() {

if (this.currentPage < this.pages) {

this.showPage(this.currentPage + 1);

}

}

this.init = function() {

var rows = document.getElementById(tableName).rows;

var records = (rows.length - 1);

this.pages = Math.ceil(records / itemsPerPage);

this.inited = true;

}

this.showPageNav = function(pagerName, positionId) {

if (! this.inited) {

alert("not inited");

return;

}

var element = document.getElementById(positionId);

var pagerHtml = '<span onclick="' + pagerName + '.prev();" class="pg-normal"> « Prev </span> ';

for (var page = 1; page <= this.pages; page++)

pagerHtml += '<span id="pg' + page + '" class="pg-normal" onclick="' + pagerName + '.showPage(' + page + ');">' + page + '</span> ';

pagerHtml += '<span onclick="'+pagerName+'.next();" class="pg-normal"> Next »</span>';

element.innerHTML = pagerHtml;

}

}

</script>

</head>


<body>
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->

    <!-- ################################################################################################ -->
    <ul class="nospace group services">
      <li class="two_fourth">
        <article>
<br>


<h3 class="heading font-x2" align="center"><b>Welcome to siRNA prediction page</b></h3>

<p>----------------------------------------------------------------------------------------------------------------------------------------------------</p>
<p align="justify">
These are predicted siRNA using surface glycoprotein of Coronavirus. Antisense sequences of siRNAs: Antisense strand targeting mRNA sequence. Position on mRNA: denotes the position of first nucleotide of mRNA target sequence. mRNA target sequence: denotes sequence of mRNA against which siRNA is generated. Target accessibility: Probability of target sequence to be unpaired for binding with siRNA. Efficacy: denotes the efficacy of siRNAs (highest efficacy more potent to degrade the mRNA). Sequences are in descending order of efficacy.
</p>
<p>------------------------------------------------------------------------------------------------------------------------------------------------------</p>



&nbsp;&nbsp;&nbsp;&nbsp; <a href="surf_sirna.csv">

<img src="images/download.png" width="20px" height="20px"></a></td></tr>
<b style='align:right'><font color= #1c7aa8>Click here to download</font color></b></a>
<div class=\"scrollable\" style="overflow-x:auto;">
<table class=\"tablesaw\" data-tablesaw-mode=\"swipe\" data-tablesaw-sortable data-tablesaw-sortable-switch data-tablesaw-minimap data-tablesaw-mode-switch>
<table id="customers" class="yui">
<?php 
$rdfile=file("surf_sirna.csv");
$c=1;
foreach($rdfile as $line){
        //echo "<tr>";
	if($c==1){
		echo "<tr>";
		$sub=explode("\t",$line);	
		foreach($sub as $l){
			echo "<td><b>$l</b></td>";
		}
		echo "</tr>";
	}
	else{
		$sub=explode("\t",$line); 
		 echo "<tr>";
		$d=1;
		foreach($sub as $l){
			if($d<3){ echo "<td>$l</td>";$gene=$l;}
			elseif ($d==3){
				$pr=$l;
                        	echo "<td>$pr
					</td>";
			}
			elseif ($d==4){
                        	echo "<td>
                                    $l
					</td>";
			}
			else {
                        	echo "<td>
				$l
					</td>";
				}
		$d++;
                }
		echo "</tr>";

	}
	$c++;
}
echo "</table>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";
?>

</table>
<div id="pageNavPosition" style="padding-top:0px" align="center">
</div>
<script type="text/javascript"><!--
var pager = new Pager('customers', 20);
pager.init();
pager.showPageNav('pager', 'pageNavPosition');
pager.showPage(1);
</script>


</div>
</body>
<br>
<?php include "footer.php"?>
